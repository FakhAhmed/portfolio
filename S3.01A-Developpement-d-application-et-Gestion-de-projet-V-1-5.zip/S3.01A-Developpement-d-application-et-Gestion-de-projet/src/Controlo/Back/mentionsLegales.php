<div class="container">
    <br>
    <h1>Mentions Légales</h1> 
    <br>
    <p><strong>Identité éditeur du site : </strong>Cédric ETCHEPARE, Samuel HENTRICS LOISTINE, Ahmed FAKHFAKH, Benjamin PEYRE</p> 
    <p><strong>Coordonnées : </strong>2 Allée du Parc Montaury, 64600 Anglet, contact@controlo-iut.fr</p> 
    <p><strong>Mentions relatives à la propriété intellectuelle : </strong>Données manipulées par l’application issues du logiciel de scolarité de l’IUT de Bayonne mais filtrées pour éviter les données personnelles (INE, adresse…). Utilisation par le secrétariat du l’IUT qui détient les droits sur ces données.</p> 
    <p><strong>Mentions relatives à l'hébergement du site : </strong>
    <p><strong>Nom : </strong>OVH</p>
    <p><strong>SAS au capital : </strong>10 174 560 €</p>
    <p><strong>RCS : </strong>Lille Métropole 424 761 419 00045</p>
    <p><strong>Code APE : </strong>2620Z</p>
    <p><strong>N° TVA : </strong>FR 22 424 761 419</p>
    <p><strong>Siège social : </strong>2 rue Kellermann - 59100 Roubaix - France</p>
    <p><strong>Président : </strong>Michel Paulin</p>
    <p><strong>N° TVA : </strong>FR 22 424 761 419</p>
    <p>OVH SAS est une filiale de la société OVH Groupe SA, société immatriculée au RCS de Lille sous le numéro 537 407 926 sise 2, rue Kellermann, 59100 Roubaix.
</p>
    </div> 