var searchData=
[
  ['js_5ffolder_5fname_0',['JS_FOLDER_NAME',['../config_8php.html#a5dc3ee60eb14815f6d3065b14229cfe6',1,'config.php']]],
  ['js_5fpath_1',['JS_PATH',['../config_8php.html#a240b66ce0c4386e8565f97e0b15f6075',1,'config.php']]]
];
