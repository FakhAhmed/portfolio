var searchData=
[
  ['back_5ffolder_5fname_0',['BACK_FOLDER_NAME',['../config_8php.html#a06a98917b735c21c1944f7d9c53fd8e1',1,'config.php']]],
  ['back_5fpath_1',['BACK_PATH',['../config_8php.html#aea5c4969abb8ffb41a45a3f777a2d7c7',1,'config.php']]]
];
