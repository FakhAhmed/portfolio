var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "Controlo", "dir_0219e3f6040368f21360b5e8bfe40506.html", "dir_0219e3f6040368f21360b5e8bfe40506" ],
    [ "config.php", "config_8php.html", "config_8php" ],
    [ "download.php", "download_8php.html", null ]
];