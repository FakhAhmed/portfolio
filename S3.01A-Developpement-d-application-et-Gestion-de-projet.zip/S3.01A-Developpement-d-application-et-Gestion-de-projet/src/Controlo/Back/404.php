<div class="container">
    <div class="col-12">
        <br>

        <h1> Error 404 </h1>

    </div>
</div>