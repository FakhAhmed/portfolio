var searchData=
[
  ['videos_5ffolder_5fname_0',['VIDEOS_FOLDER_NAME',['../config_8php.html#a0abe969f61ce55ff54ee1b352be1d88b',1,'config.php']]],
  ['videos_5fpath_1',['VIDEOS_PATH',['../config_8php.html#af4a14782b2332101b74ff48e9ffaffd9',1,'config.php']]]
];
