var searchData=
[
  ['object_5fcreation_5ffolder_5fname_0',['OBJECT_CREATION_FOLDER_NAME',['../config_8php.html#a7a10c0a2c220cf7efd56010fcb43827e',1,'config.php']]],
  ['object_5fcreation_5fpath_1',['OBJECT_CREATION_PATH',['../config_8php.html#a607910ffff68c38fecf70f9fafd92836',1,'config.php']]]
];
