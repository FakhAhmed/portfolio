var searchData=
[
  ['img_5ffolder_5fname_0',['IMG_FOLDER_NAME',['../config_8php.html#ac569ace58d792761b0730595662d0619',1,'config.php']]],
  ['img_5fpath_1',['IMG_PATH',['../config_8php.html#a394e99dc118b8893d619a8544b988d90',1,'config.php']]],
  ['import_5ffolder_5fname_2',['IMPORT_FOLDER_NAME',['../config_8php.html#aa4ff44e921f670c6ff83fd4f9c3bb178',1,'config.php']]],
  ['import_5fpath_3',['IMPORT_PATH',['../config_8php.html#a6a4331da17f275642f0576d167980e50',1,'config.php']]]
];
