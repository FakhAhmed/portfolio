# e-commerce
Ce petit projet a été réalisé lors de ma formation BUT Informatique (2ème année) à l'IUT de Bayonne et du Pays Basque dans le cadre de la ressource "R3.01 - Développement Web". Il s'agit de configurer un système pour la gestion des CD. Mettez également en place un système de connexion pour gérer les connexions des administrateurs/visiteurs du site. Il est codé en PHP et css.
