# -*- coding: utf-8 -*-
"""
Created on Fri May  6 11:12:57 2022

@author: shloistine
"""

import pyodbc
import pandas as pd
import matplotlib.pyplot as plt

conn=pyodbc.connect('DSN=bdd_accidents')

"""Receptacle pour être au début du résultat"""
cursor = conn.cursor()

def accueil():
    espacement()
    liste_choix={1:"Sur le nombre d'accidents",
                 2:"Sur le nombre d'accidents graves",
                 3:"Sur le degré de gravité",
                 4:"Sur les intempéries principales",
                 5:"Sur les causes principales "}
    print("""
    ---------------------------------------------------------
    Statistiques sur les accidents en fonction de la journée
    ---------------------------------------------------------
    
    """)

    # On affiche tous les choix possibles
    for num, raison in liste_choix.items():
        print("     ", num, " - ", raison)

    print(""" 
    ---------------------------------------------------------""")
    
    
    choix=0
    # On attend un choix correct de l'utilisateur venant de liste_choix
    while choix not in liste_choix:
        choix=int(input("Votre choix : "))
        
    # On traite son choix
    if choix==1:
        accidents()
    elif choix==2:
        accidents_graves()
    elif choix==3:
        gravite()
    elif choix==4:
        intemperie()
    elif choix==5:
        causes()
   
def accidents():
    espacement()
    # On demande à l'utilisateur quel type de luminosite
    lum=demandeLuminosite()
    # On vérifie si l'utilisateur veut une année
    if vouloirAnnee():
        # Si l'utilisateur choisit de visualiser une année, on demande une année
        annee=demandeAnnee()
        # Cas où l'on a demandé une année + toute la journée
        if lum==4:
            req="""SELECT COUNT(*) as NbAccidents, MONTH(d.DateFormatStandard) as Mois
                        FROM MAccident a
                        JOIN MDate d ON d.date_id=a.date_id
                        WHERE YEAR(d.DateFormatStandard)="""+str(annee)+"""
                        GROUP BY Mois"""
            quest1=pd.read_sql(req, conn)
            quest1.plot(kind="bar", x="Mois", y="NbAccidents")
            plt.title("Répartition du nombre d'accidents en " + str(annee))
            plt.ylabel("Nombre d'accidents")
            plt.legend().set_visible(False)
            plt.savefig('accidents_'+str(annee)+'.png')
            plt.show()
        # Cas où l'on a demandé une année + le type de luminosité distinct
        elif lum==3:
            req="""SELECT 
                        MONTH(d.DateFormatStandard) as Mois,
                        (SELECT COUNT(*) FROM MAccident a
                             JOIN MDate d ON d.date_id=a.date_id
                             JOIN MLuminosite l ON l.code=a.lum_id
                             WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
                             AND l.type_luminosite=1 AND
                             MONTH(d.DateFormatStandard)=Mois
                             ) as NbAccidentsJour, 
                        (SELECT COUNT(*) FROM MAccident a 
                             JOIN MDate d ON d.date_id=a.date_id 
                             JOIN MLuminosite l ON l.code=a.lum_id 
                             WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +""" 
                             AND l.type_luminosite=2 AND 
                             MONTH(d.DateFormatStandard)=Mois) 
                            as NbAccidentsNuit
                        FROM MAccident a 
                        JOIN MDate d ON d.date_id=a.date_id 
                        WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
                        GROUP BY Mois"""
            quest1=pd.read_sql(req, conn)
            quest1.plot(kind="bar", x="Mois", y=["NbAccidentsJour","NbAccidentsNuit"])
            plt.title("Répartition du nombre d'accidents la journée et la nuit en " + str(annee))
            plt.ylabel("Nombre d'accidents")
            plt.savefig('accidents_nuits_jours_'+str(annee)+'.png')
            plt.show()
        # Cas où l'on a demandé une année + un type de luminosité (jour ou nuit)
        else:
            req="""SELECT COUNT(*) as NbAccidents, MONTH(d.DateFormatStandard) as Mois
                    FROM MAccident a
                    JOIN MDate d ON d.date_id=a.date_id
                    JOIN MLuminosite l ON l.code=a.lum_id
                    WHERE YEAR(d.DateFormatStandard)="""+str(annee)+"""
                    AND l.type_luminosite="""+str(lum)+"""
                    GROUP BY Mois"""
            quest1=pd.read_sql(req, conn)
            quest1.plot(kind="bar", x="Mois", y="NbAccidents")
            if lum==1:
                plt.title("Répartition du nombre d'accidents la journée en " + str(annee))
            if lum==2:
                plt.title("Répartition du nombre d'accidents la nuit en " + str(annee))
            plt.ylabel("Nombre d'accidents")
            plt.legend().set_visible(False)
            plt.savefig('accidents_luminosite_'+str(annee)+'.png')
            plt.show()
    else:
        # Cas où l'on a demandé toutes les années + n'importe quel type de luminosité
        if lum==4:
            req="""SELECT COUNT(*) as NbAccidents, YEAR(d.DateFormatStandard) as Annee
                        FROM MAccident a
                        JOIN MDate d ON d.date_id=a.date_id
                        GROUP BY Annee
                    """
            quest1=pd.read_sql(req, conn)
            quest1.plot(kind="bar", x="Annee", y="NbAccidents")
            plt.title("Répartition du nombre d'accidents")
            plt.ylabel("Nombre d'accidents")
            plt.legend().set_visible(False)
            plt.savefig('accidents_toutes_annees.png')
            plt.show()
        # Cas où l'on a demandé toutes les années + les deux luminosités distinctes
        elif lum==3:
            req="""SELECT 
                        YEAR(d.DateFormatStandard) as Annee,
                        (SELECT COUNT(*) FROM MAccident a
                             JOIN MDate d ON d.date_id=a.date_id
                             JOIN MLuminosite l ON l.code=a.lum_id
                             WHERE YEAR(d.DateFormatStandard)=Annee
                             AND l.type_luminosite=1) as NbAccidentsJour, 
                        (SELECT COUNT(*) FROM MAccident a 
                             JOIN MDate d ON d.date_id=a.date_id 
                             JOIN MLuminosite l ON l.code=a.lum_id 
                             WHERE YEAR(d.DateFormatStandard)=Annee 
                             AND l.type_luminosite=2)
                            as NbAccidentsNuit
                        FROM MAccident a 
                        JOIN MDate d ON d.date_id=a.date_id 
                        GROUP BY Annee"""
            quest1=pd.read_sql(req, conn)
            quest1.plot(kind="bar", x="Annee", y=["NbAccidentsJour", "NbAccidentsNuit"])
            plt.title("Répartition du nombre d'accidents la journée et la nuit")
            plt.ylabel("Nombre d'accidents")
            plt.savefig('accidents_jours_nuits.png')
            plt.show()
        # Cas où l'on a demandé toutes les années + un type de luminosité
        else:
            req="""SELECT COUNT(*) as NbAccidents, YEAR(d.DateFormatStandard) as Annee
                        FROM MAccident a
                        JOIN MDate d ON d.date_id=a.date_id
                        JOIN MLuminosite l ON l.code=a.lum_id
                        WHERE l.type_luminosite="""+str(lum)+"""
                        GROUP BY Annee
                    """
            quest1=pd.read_sql(req, conn)
            quest1.plot(kind="bar", x="Annee", y="NbAccidents")
            if lum==1:
                plt.title("Répartition du nombre d'accidents la journée")
            if lum==2:
                plt.title("Répartition du nombre d'accidents la nuit")
            plt.ylabel("Nombre d'accidents")
            plt.legend().set_visible(False)
            plt.savefig('accidents_luminosite.png')
            plt.show()
    accueil()        
   
    


def accidents_graves():
    espacement()
    # Demande de la luminosité
    lum=demandeLuminosite()
    # Demande si l'on souhaite traiter sur une année
    if vouloirAnnee():
        # Demande l'année en question si on souhaite traiter sur une année
        annee=demandeAnnee()
        # Si année + luminosité sur toute une journée
        if lum==4:
            req="""SELECT COUNT(a.gravite) as NbAGraves, MONTH(d.DateFormatStandard) as Mois
                        FROM MAccident a
                        JOIN MDate d ON d.date_id=a.date_id
                        WHERE YEAR(d.DateFormatStandard)="""+str(annee)+"""
                        AND a.gravite=3
                        GROUP BY Mois"""
            quest2=pd.read_sql(req, conn)
            quest2.plot(kind="bar", x="Mois", y="NbAGraves")
            plt.title("Répartition du nombre d'accidents graves en " + str(annee))
            plt.ylabel("Nombre d'accidents graves")
            plt.legend().set_visible(False)
            plt.savefig('grave_'+str(annee)+'.png')
            plt.show()
        # Si année + luminosité sur toute une journée (Jour/Nuit)
        elif lum==3:
            req="""SELECT 
                        MONTH(d.DateFormatStandard) as Mois,
                        (SELECT COUNT(*) FROM MAccident a
                             JOIN MDate d ON d.date_id=a.date_id
                             JOIN MLuminosite l ON l.code=a.lum_id
                             WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
                             AND l.type_luminosite=1 AND
                             MONTH(d.DateFormatStandard)=Mois
                             AND a.gravite=3
                             ) as NbAccidentsJour, 
                        (SELECT COUNT(*) FROM MAccident a 
                             JOIN MDate d ON d.date_id=a.date_id 
                             JOIN MLuminosite l ON l.code=a.lum_id 
                             WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +""" 
                             AND l.type_luminosite=2 AND 
                             MONTH(d.DateFormatStandard)=Mois
                             AND a.gravite=3) 
                            as NbAccidentsNuit
                        FROM MAccident a 
                        JOIN MDate d ON d.date_id=a.date_id 
                        WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
                        AND a.gravite=3
                        GROUP BY Mois"""
            quest2=pd.read_sql(req, conn)
            quest2.plot(kind="bar", x="Mois", y=["NbAccidentsJour","NbAccidentsNuit"])
            plt.title("Répartition du nombre d'accidents graves la journée et la nuit en " + str(annee))
            plt.ylabel("Nombre d'accidents graves")
            plt.savefig('grave_nuits_jours_'+str(annee)+'.png')
            plt.show()
        # Si année + une luminosité (Jour ou nuit)
        else:
            req="""SELECT COUNT(a.gravite) as NbAGraves, MONTH(d.DateFormatStandard) as Mois
                    FROM MAccident a
                    JOIN MDate d ON d.date_id=a.date_id
                    JOIN MLuminosite l ON l.code=a.lum_id
                    WHERE YEAR(d.DateFormatStandard)="""+str(annee)+"""
                    AND l.type_luminosite="""+str(lum)+"""
                    AND a.gravite=3
                    GROUP BY Mois"""
            quest2=pd.read_sql(req, conn)
            quest2.plot(kind="bar", x="Mois", y="NbAGraves")
            if lum==1:
                plt.title("Répartition du nombre d'accidents graves la journée en " + str(annee))
            if lum==2:
                plt.title("Répartition du nombre d'accidents graves la nuit en " + str(annee))
            plt.ylabel("Nombre d'accidents graves")
            plt.legend().set_visible(False)
            plt.savefig('grave_luminosite_'+str(annee)+'.png')
            plt.show()
    else:
        # luminosité sur toute une journée
        if lum==4:
            req="""SELECT COUNT(a.gravite) as NbAGraves, YEAR(d.DateFormatStandard) as Annee
                        FROM MAccident a
                        JOIN MDate d ON d.date_id=a.date_id
                        WHERE a.gravite=3
                        GROUP BY Annee
                    """
            quest2=pd.read_sql(req, conn)
            quest2.plot(kind="bar", x="Annee", y="NbAGraves")
            plt.title("Répartition du nombre d'accidents graves")
            plt.ylabel("Nombre d'accidents graves")
            plt.legend().set_visible(False)
            plt.savefig('grave_toutes_annees.png')
            plt.show()
        # luminosité sur toute une journée (Jour/Nuit)
        elif lum==3:
            req="""SELECT 
                        YEAR(d.DateFormatStandard) as Annee,
                        (SELECT COUNT(*) FROM MAccident a
                             JOIN MDate d ON d.date_id=a.date_id
                             JOIN MLuminosite l ON l.code=a.lum_id
                             WHERE YEAR(d.DateFormatStandard)=Annee
                             AND l.type_luminosite=1
                             AND a.gravite=3
                             ) as NbAccidentsJour, 
                        (SELECT COUNT(*) FROM MAccident a 
                             JOIN MDate d ON d.date_id=a.date_id 
                             JOIN MLuminosite l ON l.code=a.lum_id 
                             WHERE YEAR(d.DateFormatStandard)=Annee 
                             AND l.type_luminosite=2
                             AND a.gravite=3) 
                            as NbAccidentsNuit
                        FROM MAccident a 
                        JOIN MDate d ON d.date_id=a.date_id 
                        WHERE a.gravite=3
                        GROUP BY Annee"""
            quest2=pd.read_sql(req, conn)
            quest2.plot(kind="bar", x="Annee", y=["NbAccidentsJour","NbAccidentsNuit"])
            plt.title("Répartition du nombre d'accidents graves la journée et la nuit")
            plt.ylabel("Nombre d'accidents graves")
            plt.legend().set_visible(False)
            plt.savefig('grave_jours_nuits.png')
            plt.show()
        # une luminosité 
        else:
            req="""SELECT COUNT(a.gravite) as NbAGraves, YEAR(d.DateFormatStandard) as Annee
                        FROM MAccident a
                        JOIN MDate d ON d.date_id=a.date_id
                        JOIN MLuminosite l ON l.code=a.lum_id
                        WHERE l.type_luminosite="""+str(lum)+"""
                        AND a.gravite=3
                        GROUP BY Annee
                    """
            quest2=pd.read_sql(req, conn)
            quest2.plot(kind="bar", x="Annee", y="NbAGraves")
            if lum==1:
                plt.title("Répartition du nombre d'accidents graves la journée")
            if lum==2:
                plt.title("Répartition du nombre d'accidents graves la nuit")
            plt.ylabel("Nombre d'accidents graves")
            plt.legend().set_visible(False)
            plt.savefig('grave_luminosite.png')
            plt.show()
    accueil()
    
    
def gravite():
    espacement()
    # Demande de la luminosité
    lum=demandeLuminosite2()
    # Demande si l'on souhaite traiter sur une année
    if vouloirAnnee():
        # Demande l'année en question si on souhaite traiter sur une année
        annee=demandeAnnee()
        # Si année + luminosité sur toute une journée
        if lum==3:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MDate d ON d.date_id=a.date_id
                WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""),2)     
                                 as NbGravite,
            a.gravite
            FROM MAccident a
            JOIN MDate d ON d.date_id=a.date_id
            WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
            GROUP BY a.gravite
            ORDER BY NbGravite DESC
            LIMIT 4
            """
        # Si année + une luminosité (Jour ou nuit)
        else:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MDate d ON d.date_id=a.date_id
                JOIN MLuminosite l ON l.code=a.lum_id
                WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
                AND l.type_luminosite="""+str(lum)+"""),2) 
            as NbGravite, a.gravite
            FROM MAccident a
            JOIN MLuminosite l ON l.code=a.lum_id
            JOIN MDate d ON d.date_id=a.date_id
            WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
            AND l.type_luminosite="""+str(lum)+"""
            GROUP BY a.gravite
            ORDER BY NbGravite DESC
            LIMIT 4"""
            
    else:
        if lum==3:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MDate d ON d.date_id=a.date_id),2) 
        as NbGravite, a.gravite
            FROM MAccident a
            JOIN MLuminosite l ON l.code=a.lum_id
            GROUP BY a.gravite
            ORDER BY NbGravite DESC
            LIMIT 4"""
        else:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MDate d ON d.date_id=a.date_id
                JOIN MLuminosite l ON l.code=a.lum_id
                AND l.type_luminosite="""+str(lum)+"""),2)  as NbGravite, a.gravite
            FROM MAccident a
            JOIN MLuminosite l ON l.code=a.lum_id
            WHERE l.type_luminosite="""+str(lum)+"""
            GROUP BY a.gravite
            ORDER BY NbGravite DESC
            LIMIT 4"""
            
    espacement()        
    print("""
    ---------------------------------------------------------
    Classement de la gravité la plus présente selon vos choix (du moins grave (0) au plus grave(3))
    ---------------------------------------------------------
    
        
    """)
    
    cursor.execute(req)
    i=1
    for row in cursor.fetchall():
        print("      N°"+ str(i)+": " + str(row[1]) + " (" + str(row[0]) + "%)")
        i+=1
    
    print("")
    attClic=input("Appuyez sur 'Entrer' pour retourner à l'accueil...")
    accueil()
    
def intemperie():
    espacement()
    # Demande la luminosité
    lum=demandeLuminosite2()
    # Demande si l'utilisateur veut choisir une année
    if vouloirAnnee():
        # Selection de l'année
        annee=demandeAnnee()
        # Si annee + luminosité = toutes luminosités
        if lum==3:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MIntemperie i ON i.code=a.intemp_id
                JOIN MDate d ON d.date_id=a.date_id
                WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""))     
                                 as NbNomIntemperie,
            i.libelle
            FROM MAccident a
            JOIN MIntemperie i ON i.code=a.intemp_id
            JOIN MDate d ON d.date_id=a.date_id
            WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
            GROUP BY i.libelle
            ORDER BY NbNomIntemperie DESC
            LIMIT 3
            """
        # Si annee + luminosité = une luminosité
        else:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MIntemperie i ON i.code=a.intemp_id
                JOIN MDate d ON d.date_id=a.date_id
                JOIN MLuminosite l ON l.code=a.lum_id
                WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
                AND l.type_luminosite="""+str(lum)+""")) 
            as NbNomIntemperie, i.libelle
            FROM MAccident a
            JOIN MIntemperie i ON i.code=a.intemp_id
            JOIN MLuminosite l ON l.code=a.lum_id
            JOIN MDate d ON d.date_id=a.date_id
            WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
            AND l.type_luminosite="""+str(lum)+"""
            GROUP BY i.libelle
            ORDER BY NbNomIntemperie DESC
            LIMIT 3"""
    else:
        # Si luminosité = toute luminosité
        if lum==3:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MIntemperie i ON i.code=a.intemp_id
                JOIN MDate d ON d.date_id=a.date_id)) 
        as NbNomIntemperie, i.libelle
            FROM MAccident a
            JOIN MIntemperie i ON i.code=a.intemp_id
            JOIN MLuminosite l ON l.code=a.lum_id
            GROUP BY i.libelle
            ORDER BY NbNomIntemperie DESC
            LIMIT 3"""
        # Si luminosité = une luminosité
        else:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MIntemperie i ON i.code=a.intemp_id
                JOIN MDate d ON d.date_id=a.date_id
                JOIN MLuminosite l ON l.code=a.lum_id
                AND l.type_luminosite="""+str(lum)+"""))  as NbNomIntemperie, i.libelle
            FROM MAccident a
            JOIN MIntemperie i ON i.code=a.intemp_id
            JOIN MLuminosite l ON l.code=a.lum_id
            WHERE l.type_luminosite="""+str(lum)+"""
            GROUP BY i.libelle
            ORDER BY NbNomIntemperie DESC
            LIMIT 3"""
            
    espacement()        
    print("""
    ---------------------------------------------------------
    Classement des trois premiers intempéries selon vos choix
    ---------------------------------------------------------
    
        
    """)
    
    cursor.execute(req)
    i=1
    for row in cursor.fetchall():
        print("      N°"+ str(i)+": " + str(row[1]) + " (" + str(row[0]) + "%)")
        i+=1
    
    print("")
    attClic=input("Appuyez sur 'Entrer' pour retourner à l'accueil...")
    accueil()


def causes():
    espacement()
    # Demande la luminosité
    lum=demandeLuminosite2()
    # Demande si l'utilisateur veut choisir une année
    if vouloirAnnee():
        # Selection de l'année
        annee=demandeAnnee()
        # Si annee + luminosité = toutes luminosités
        if lum==3:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MCause c ON a.cause_id=c.Cause
                JOIN MDate d ON d.date_id=a.date_id
                WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""))     
                                 as NbNomCause,
            c.libelle
            FROM MAccident a
            JOIN MCause c ON a.cause_id=c.Cause
            JOIN MDate d ON d.date_id=a.date_id
            WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
            GROUP BY c.libelle
            ORDER BY NbNomCause DESC
            LIMIT 3
            """
        # Si annee + luminosité = une luminosité
        else:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MCause c ON a.cause_id=c.Cause
                JOIN MDate d ON d.date_id=a.date_id
                JOIN MLuminosite l ON l.code=a.lum_id
                WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
                AND l.type_luminosite="""+str(lum)+""")) 
            as NbNomCause, c.libelle
            FROM MAccident a
            JOIN MCause c ON a.cause_id=c.Cause
            JOIN MLuminosite l ON l.code=a.lum_id
            JOIN MDate d ON d.date_id=a.date_id
            WHERE YEAR(d.DateFormatStandard)="""+ str(annee) +"""
            AND l.type_luminosite="""+str(lum)+"""
            GROUP BY c.libelle
            ORDER BY NbNomCause DESC
            LIMIT 3"""
    else:
        # Si luminosité = toute luminosité
        if lum==3:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MCause c ON a.cause_id=c.Cause
                JOIN MDate d ON d.date_id=a.date_id)) 
        as NbNomCause, c.libelle
            FROM MAccident a
            JOIN MCause c ON a.cause_id=c.Cause
            JOIN MLuminosite l ON l.code=a.lum_id
            GROUP BY c.libelle
            ORDER BY NbNomCause DESC
            LIMIT 3"""
        # Si luminosité = une luminosité
        else:
            req="""
            SELECT ROUND(COUNT(*)*100/(
                SELECT COUNT(*)
                FROM MAccident a
                JOIN MCause c ON a.cause_id=c.Cause
                JOIN MDate d ON d.date_id=a.date_id
                JOIN MLuminosite l ON l.code=a.lum_id
                AND l.type_luminosite="""+str(lum)+"""))  as NbNomCause, c.libelle
            FROM MAccident a
            JOIN MCause c ON a.cause_id=c.Cause
            JOIN MLuminosite l ON l.code=a.lum_id
            WHERE l.type_luminosite="""+str(lum)+"""
            GROUP BY c.libelle
            ORDER BY NbNomCause DESC
            LIMIT 3"""
            
    espacement()        
    print("""
    ---------------------------------------------------------
    Classement des trois premiers intempéries selon vos choix
    ---------------------------------------------------------
    
        
    """)
    
    cursor.execute(req)
    i=1
    for row in cursor.fetchall():
        print("      N°"+ str(i)+": " + str(row[1]) + " (" + str(row[0]) + "%)")
        i+=1
    
    print("")
    attClic=input("Appuyez sur 'Entrer' pour retourner à l'accueil...")
    accueil()
    
   
    
    
    

def demandeLuminosite():
    """Permet de demander quel type de luminosité souhaite l'utilisateur"""
    espacement()
    choix_luminosite={1:"Jour",
                      2:"Nuit",
                      3:"Jour/Nuit (/!\ Génération longue)",
                      4:"Toute la journée"}
    
    print("""
    ---------------------------------------------------------
     Choix de la luminosité
    ---------------------------------------------------------
          """)
          
    for num, raison in choix_luminosite.items():
        print("     ", num, " - ", raison)
        
        
    print(""" 
    ---------------------------------------------------------""")
    
    
    choix=0
    while choix not in choix_luminosite:
        choix=int(input("Votre choix : "))   
    return choix

def demandeLuminosite2():
    """Permet de demander quel type de luminosité souhaite l'utilisateur
    de façon plus simplifiée"""
    espacement()
    choix_luminosite={1:"Jour",
                      2:"Nuit",
                      3:"Toute la journée"}
    
    print("""
    ---------------------------------------------------------
     Choix de la luminosité
    ---------------------------------------------------------
          """)
          
    for num, raison in choix_luminosite.items():
        print("     ", num, " - ", raison)
        
        
    print(""" 
    ---------------------------------------------------------""")
    
    
    choix=0
    while choix not in choix_luminosite:
        choix=int(input("Votre choix : "))   
    return choix




def vouloirAnnee():
    espacement()
    """Demande à l'utilisateur si celui-ci souhaite prendre une année pour sa
    requetes ou toutes les années"""
    
    
    demande_choix={1:"Choisir une année",
                   2:"Prendre toutes les années"}
    
    print("""
    ---------------------------------------------------------
     Souhaitez-vous choisir une année ?
    ---------------------------------------------------------
          """)
          
    for num, raison in demande_choix.items():
        print("     ", num, " - ", raison)
        
        
    print(""" 
    ---------------------------------------------------------""")
    
    
    choix=0
    while choix not in demande_choix:
        choix=int(input("Votre choix : "))   
        
    if choix==1:
        return True
    elif choix==2:
        return False





def demandeAnnee():
    espacement()
    """Permet la selection d'une année"""
    
    
    print("""
    ---------------------------------------------------------
     Selection d'une année entre 1984 et 1998
    ---------------------------------------------------------
    """)
    
    choix=0
    while choix < 1984 or choix > 1998:
        choix=int(input("Année selectionnée : "))   
    return choix
    



def espacement():
    print("""
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          """)



accueil()