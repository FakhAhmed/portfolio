# -*- coding: utf-8 -*-
"""
Nom : Partie 2
Description : Partie 2 de la SAE S2.02
Auteurs : Samuel HENTRICS LOISTINE, Ahmed FAKHFAKH
"""

import json
from math import sin, cos, acos, pi
import random

import numpy as np
from graphics import *

"""
------------------------------------------------------------------------------------------------------------------------

                                                    PARTIE 1

------------------------------------------------------------------------------------------------------------------------
"""


""" Etape A """

fichier = open("./donneesbus.json", 'r') #Ouverture du fichier JSON en lecture
donneesbus = json.load(fichier) # Importation du JSON dans un dictionnaire donneesbus
fichier.close() # Fermeture de la lecture du fichier

""" ETAPE B """

noms_arrets = [] # Création du tableau noms_arrets
for key in donneesbus: # Parcours des clés du dictionnaire donneesbus
    noms_arrets.append(key) # Ajout de la clé dans nom_arrets
    
# Etape C

def nom(ind):
    return noms_arrets[ind]

#print(nom(1))


def indice_som(nom_som):
    i=0
    trouve=False
    while i!=len(noms_arrets):
        if noms_arrets[i]==nom_som:
            trouve=True
            ind=i
            break
        i+=1
    
    if trouve:
        return ind
    else:
        return None
    
#print(indice_som('NOST'))

def latitude(nom_som):
    return donneesbus[nom_som][0]

#print(voisin('NOVE'))

def longitude(nom_som):
    return donneesbus[nom_som][1]

#print(voisin('NOVE'))

def voisin(nom_som):
    return donneesbus[nom_som][2]
    
#print(voisin('NOVE'))


# Etape D


dic_bus={}
for key in donneesbus:
    dic_bus[key] = voisin(key)

mat_bus=[]
for i in range(len(noms_arrets)):
    mat_bus.append([0]*len(noms_arrets))
    for v_s in voisin(nom(i)):
        mat_bus[i][indice_som(v_s)]=1
        
# Etape E

#########################################################
# calcul de la distance entre deux points A et B dont   #
# on connait la lattitude et la longitude               #
#########################################################
def distanceGPS(latA, latB, longA, longB):
    # Conversions des latitudes en radians
    ltA=latA/180*pi
    ltB=latB/180*pi
    loA=longA/180*pi
    loB=longB/180*pi
    # Rayon de la terre en mètres (sphère IAG-GRS80)
    RT = 6378137
    # Angle en radians entre les 2 points
    S = acos(round(sin(ltA)*sin(ltB)+cos(ltA)*cos(ltB)*cos(abs(loB-loA)),14))
    #♦ distance entre les 2 points, comptée sur un arc de grand cercle
    return S*RT

def distarrets(arret1, arret2):
    return distanceGPS(latitude(arret1),latitude(arret2), longitude(arret1), longitude(arret2))

def distarc(arret1, arret2):
    if arret2 in voisin(arret1):
        return distarrets(arret1, arret2)
    return float('inf')
        

# Etape F

n=len(noms_arrets)
poids_bus=[[np.inf for loop in range(n)] for loop in range(n)]
for src in range(n):
    for dest in range(n):
        if src==dest:
            poids_bus[src][dest]=0
        else:
            poids_bus[src][dest]=distarc(nom(src),nom(dest))

#print(M)

"""
------------------------------------------------------------------------------------------------------------------------

                                                    PARTIE 2

------------------------------------------------------------------------------------------------------------------------
"""

def extract_min(L,dist):
    """
    Fonction utile pour prendre le sommet ayant une distance minimum pour l'algorithme de Dijkstra
    :param L: Tableau contenant les sommets restants à traiter
    :param dist: Tableau contenant les distances
    :return: Retourne l'indice du sommet de la liste L ayant une distance minimum
    """

    minimum=float('inf')
    s_min=0
    for i in range(len(L)):
        if dist[L[i]]!=float('inf'):       
            if dist[L[i]]<minimum:
                minimum=dist[L[i]]
                s_min=i
    return s_min
        


def recreerChemin(s1,s2,lstPred):
    """
    Fonction permettant de retourner dans un tableau le chemin à parcourir pour aller de s1 à s2
    grâce à la liste des prédécesseurs (lstPred)


    :param s1: Sommet de début du chemin
    :param s2: Sommet de fin du chemin
    :param lstPred: Liste des prédécesseurs (tableau à une dimension)
    :return: retourne le chemin pour aller de s1 à s2
    """

    """------------------------------------------------------------
                            Initialisation
    ------------------------------------------------------------"""

    chemin = [s2]
    s_pred = indice_som(s2)

    """------------------------------------------------------------
                            Traitements
    ------------------------------------------------------------"""

    # On va remonter tous les prédécesseurs de s2 jusqu'à s1 pour reconstituer le chemin
    while nom(s_pred) != s1:
        s_pred = lstPred[s_pred]
        chemin.append(nom(s_pred))
    # On inverse le tableau pour que l'ordre soit correct
    chemin.reverse()
    return chemin

# Dijkstra
         
def Dijkstra(arret_dep,arret_arriv):
    """
    Fonction permettant de calculer le chemin avec un poids minimum de l'arret_dep à l'arret_arriv selon
    l'algorithme de Dijkstra

    :param arret_dep: Point de départ
    :param arret_arriv: Point d'arrivé (on retournera sa distance de arret_dep jusqu'à lui)
    :return: Retourne la distance pour arriver jusqu'à arret_arriv et le chemin à parcourir
    """

    """------------------------------------------------------------
                            Initialisation
    ------------------------------------------------------------"""
    n = len(poids_bus)
    dist=[float('inf')]*n
    pred=[None]*n
    L=[s for s in range(n)]
    s = indice_som(arret_dep)
    dist[s]=0

    """------------------------------------------------------------
                            Traitements
    ------------------------------------------------------------"""

    while L != []: # On traite tant que tous les sommets n'ont pas été vus
        s = extract_min(L, dist) # On va prendre le sommet ayant un poids minimum parmi ceux restant à traiter
        for succ in voisin(nom(L[s])):
            succ=indice_som(succ)

            # Parmis les voisins du sommet ayant un poids minimum, on vérifie si un nouveau chemin
            # est plus court que celui actuel
            if poids_bus[L[s]][succ]+dist[L[s]]< dist[succ]:
                # Si c'est le cas, on met à jour son poids ainsi que son prédécesseur qui devient s
                dist[succ]= poids_bus[L[s]][succ]+dist[L[s]]
                pred[succ]=L[s]

        # Si on est arrivé au sommet d'arrivé, on a fini notre algorithme (pas besoin d'aller plus loin
        # dans ce cas puisqu'on s'interesse jusqu'à arret_arriv, on optimise donc le programme)
        if nom(L[s]) == arret_arriv:
            break

        # On a traité le sommet s de la liste L, on peut le retirer
        L.pop(s)

    # Recréation du chemin
    chemin = recreerChemin(arret_dep, arret_arriv, pred)

    # Fin du programme, on retourne la distance pour arriver jusqu'à arret_arriv et le chemin à parcourir
    return (dist[indice_som(arret_arriv)],chemin)


#print("Dijkstra :", Dijkstra('AEROPO', 'HDVBAY'))

# Bellman

def Bellman(arret_dep,arret_arriv):
    """
    Fonction permettant de calculer le chemin avec un poids minimum de l'arret_dep à l'arret_arriv selon
    l'algorithme de Bellman

    :param arret_dep: Point de départ
    :param arret_arriv: Point d'arrivé (on retournera sa distance de arret_dep jusqu'à lui)
    :return: Retourne la distance pour arriver jusqu'à arret_arriv et le chemin à parcourir
    """

    """------------------------------------------------------------
                            Initialisation
    ------------------------------------------------------------"""

    n=len(poids_bus)
    dist=[float("inf")]*n
    pred=[None]*n

    """------------------------------------------------------------
                            Traitements
    ------------------------------------------------------------"""

    s=indice_som(arret_dep)
    dist[s]=0
    for i in range(n-1): # Relacher tous les arcs du graphe n-1 fois
        for s in range(n): # ?
            for succ in voisin(nom(s)): # ?
                succ=indice_som(succ)
                # Relâchement de l'arc(s,succ)
                if poids_bus[s][succ]+dist[s]< dist[succ]:
                    dist[succ]= poids_bus[s][succ]+dist[s]
                    pred[succ]=s


    # Recréation du chemin
    chemin = recreerChemin(arret_dep, arret_arriv, pred)

    return (dist[indice_som(arret_arriv)],chemin)


#print("Bellman : ", Bellman('AEROPO', 'HDVBAY'))



def FloydWarshall(arret_dep, arret_arriv):
    """
    Fonction permettant de calculer le chemin avec un poids minimum de l'arret_dep à l'arret_arriv selon
    l'algorithme de Floyd Warshall

    :param arret_dep: Point de départ
    :param arret_arriv: Point d'arrivé (on retournera sa distance de arret_dep jusqu'à lui)
    :return: Retourne la distance pour arriver jusqu'à arret_arriv et le chemin à parcourir
    """

    """------------------------------------------------------------
                            Initialisation
    ------------------------------------------------------------"""

    n = len(poids_bus)
    dist = poids_bus
    # Création du tableau a deux dimensions pour les prédécesseurs
    pred = [[None for i in range(n)] for i in range(n)]
    for i in range(n):
        for j in range(n):
            if dist[i][j] != float('inf') and dist[i][j]!=0 :
                # Cas où il existe une distance du point i au point j, cela veut dire que le
                # point j à pour prédécesseur i
                pred[i][j]=i

    """------------------------------------------------------------
                            Traitements
    ------------------------------------------------------------"""

    for i in range(n): # On boucle pour parcourir tous les sommets
        for ligne in range(n): # On boucle pour parcourir toutes les lignes
            for colonne in range(n): # On boucle pour parcourir toutes les colonnes
                if (dist[ligne][i] + dist[i][colonne] < dist[ligne][colonne]):
                    # Si notre chemin est plus court, on modifie la distance et le prédécesseur
                    dist[ligne][colonne] = dist[ligne][i] + dist[i][colonne]
                    pred[ligne][colonne] = pred[i][colonne]


    # Recréation du chemin
    chemin=[arret_arriv]
    s = pred[indice_som(arret_dep)][indice_som(arret_arriv)]
    while nom(s) != arret_dep:
        chemin.append(nom(s))
        s = pred[indice_som(arret_dep)][s]
    chemin.append(nom(s))
    chemin.reverse()


    return (dist[indice_som(arret_dep)][indice_som(arret_arriv)], chemin)

#print("Floyd :", FloydWarshall("AEROPO", "HDVBAY"))


# -----------------------------------------------------------------
#                           PARTIE  3
# -----------------------------------------------------------------




def infoLatitude():
    """
    Fonction permettant de retourner le plus petit et le plus grand latitude d'un arret 
    """
    min=latitude(nom(1))
    max=latitude(nom(1))
    for arret in donneesbus:
        if latitude(arret)<min:
            min=latitude(arret)
        if latitude(arret)>max:
            max=latitude(arret)
    return min, max

def infoLongitude():
    """
    Fonction permettant de retourner le plus petit et le plus grand longitude d'un arret 
    """
    min=longitude(nom(1))
    max=longitude(nom(1))
    for arret in donneesbus:
        if longitude(arret)<min:
            min=longitude(arret)
        if longitude(arret)>max:
            max=longitude(arret)
    return min, max

#print(infoLatitude(), infoLongitude())

def calculAffichage(arret):
    """
    Fonction permettant de changer les valeurs de latitude et longitude
    d'un arret pour qu'ils soient adaptés à la zone de dessin
    """
    minLong,maxLong=infoLongitude()
    minLat,maxLat=infoLatitude()
    difLong=maxLong-minLong
    difLat=maxLat-minLat
    """ On a multuplier la différence par 870 et on a ajouter 8 pour que 
    les cercles ne soient pas en dehors de la zone du dessin"""
    long=((longitude(arret)-minLong)*870/difLong)+8
    lat=((latitude(arret)-minLat)*870/difLat)+8
    return (long, 900-lat)
    
def affichage(win, chemin):
    win.setBackground("white")

    """------------------------------------------------------------
                            Partie dessin
    ------------------------------------------------------------"""

    """" Dessiner tous les arrets"""
    for arret in noms_arrets:
        c = Circle(Point(calculAffichage(arret)[0], calculAffichage(arret)[1]), 4)
        c.draw(win)
    """" Dessiner le chemin """

    for i in range(len(chemin) - 1):
        pointALong = calculAffichage(chemin[i])[0]
        pointALat = calculAffichage(chemin[i])[1]
        pointBLong = calculAffichage(chemin[i + 1])[0]
        pointBLat = calculAffichage(chemin[i + 1])[1]

        # Point A
        r = random.randint(0, 255)
        v = random.randint(0, 255)
        b = random.randint(0, 255)
        c = Circle(Point(pointALong, pointALat), 4)
        c.setFill((color_rgb(r, v, b)))
        c.draw(win)

        # Ligne entre A et B
        ligne = Line(Point(pointALong, pointALat), Point(pointBLong, pointBLat))
        ligne.setFill((color_rgb(r, v, b)))
        ligne.draw(win)

        # Point B
        c = Circle(Point(pointBLong, pointBLat), 4)
        c.setFill((color_rgb(r, v, b)))
        c.draw(win)
        update(2)
 
    win.getMouse()
    win.close()

def dijkstraAffichage(arret_dep, arret_arriv):
    """
    Fonction principale permettant de dessiner les cercles
    et puis le chemin d'un arret à un autre
    """
    
    """------------------------------------------------------------
                            Initialisation
        Définir la fenetre de dessin et l'afficher sur l'ecran
    ------------------------------------------------------------"""
    
    win = GraphWin("Dijkstra evolution", 900, 900)
    chemin=Dijkstra(arret_dep, arret_arriv)[1]
    affichage(win, chemin)
    
dijkstraAffichage("AEROPO", "HDVBAY")


def bellmanAffichage(arret_dep, arret_arriv):
    """
    Fonction principale permettant de dessiner les cercles
    et puis le chemin d'un arret à un autre
    """
    
    """------------------------------------------------------------
                            Initialisation
        Définir la fenetre de dessin et l'afficher sur l'ecran
    ------------------------------------------------------------"""
    
    win = GraphWin("Bellman evolution", 900, 900)
    chemin=Bellman(arret_dep, arret_arriv)[1]
    affichage(win, chemin)
    
# bellmanAffichage("AEROPO", "HDVBAY")

def floydWarshallAffichage(arret_dep, arret_arriv):
    """
    Fonction principale permettant de dessiner les cercles
    et puis le chemin d'un arret à un autre
    """
    
    """------------------------------------------------------------
                            Initialisation
        Définir la fenetre de dessin et l'afficher sur l'ecran
    ------------------------------------------------------------"""
    
    win = GraphWin("Floyd Warshall evolution", 900, 900)
    chemin = FloydWarshall(arret_dep, arret_arriv)[1]
    affichage(win, chemin)
    
#floydWarshallAffichage("AEROPO", "HDVBAY")